This server is a Multithreaded TFTP Server based on Trivial File Transfer Protocol
and is normally used for PXE Boot or storing/retrieving router images. It supports advance
options like tsize, blksize, interval and Port Ranges.

MultiThreaded server (TFTPServerMTV1.4Beta) listens on liartening port for new requests,
however further communication is done on any free server port (from specified port range),
using new independent thread.

If you are not able to open multiple ports in firewall, other than listening port, you
can try single port version (TFTPServerSPV1.31) of this server. Single port version responds
on same port where it listens. Single port version can also serve multiple clients
at same time despite single port/thread being used. It is only little slower than
multithreaded server.

This is sixth stable Release 1.4Beta

NEW FEATURES in Release 1.4Bets

1) This Vesion Supports Thread Pool, which improves performance.

BUGS FIXED in Release 1.31
1) Max Block Size is 65503 now.
2) Code Cleanup and More Error Handling

NEW FEATURES in Release 1.3

1) Listening ports can also be specified.
2) Block size can now be as large as 65503.
3) Block Number rollover added, allowing transfer of files of any size.

NEW FEATURES in Release 1.2

1) Multiple Listening Interfaces can be specified.
2) Logging has been added.
3) Multiple directories can be added to home using aliases
4) Permitted Hosts can be specified

   
INSTALLATION

Installer automatically installs the program.
For Windows NT/XP/2K it should be installed as Service (recommended).

CONFIGURATION

You need home directory to be set in TFTPServer.ini file,
you can ignore other parameters like blksize, timeout and interval.

LICENSE

1) This program is released under GNU GENERAL PUBLIC LICENSE, Version 2, June 1991
2) This document is also released under above license.

DEBUG

If program is not responding:-

1) Check network hardware.
2) Check the log file or Run StandAlone, it will provide all debug information
   as it verbatim the activities.
3) Errors like "bind failed" means another tftpserver is running and listening
   at port 69. You can only have one tftp server running at a time. This error may also
   come if interface specified under [LISTEN-ON] is not physically available on Server.
   If you have specified [LISTEN-ON] IPs, check that IP and interface.
4) Max size of file being transfered depends on block size, the max block count being 65536,
   it would be 512*65536 or 32MB. This limitation can be increased by increasing block size
   upto 65531 which makes the max file size to 4.2 GB. However the block size also depent on
   client. Some clients like Linux support block number rollover, which make the max file size
   unlimited, irrespective of block size.

UNINSTALLATION

Goto Control Panel and uninstall the program. Uninstall the NT Service first from Start Menu.

If you find any problem with this program or need more features, please send mail to achaldhir@gmail.com.
You may also send thanks email if it works fine for you.
